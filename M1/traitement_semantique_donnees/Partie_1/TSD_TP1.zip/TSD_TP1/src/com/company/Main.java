package com.company;

import java.util.Scanner;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Property;
import org.apache.jena.rdf.model.Resource;

import static org.apache.jena.ontology.OntModelSpec.*;

public class Main {

    public static void main( String[] args )
    {
        grapheRDF();
    }

    /**
     * Méthode permettant de choisir le format du fichier sortie dans la console
     * @return String le format choisi grâce à un menu
     */
    public static String choixExtension() {
        Scanner scanner = new Scanner(System.in);
        Integer choix = null;
        do {
            try {
                System.out.println("\n\n\n***MENU***\n");
                System.out.println("Sous quelle forme voulez vous votre document (tapez le numéro correspondant): \n");
                System.out.println("1 : RDF/XML \n");
                System.out.println("2 : Turtle (temporairement indisponible) \n");
                System.out.println("3 : Json (temporairement indisponible) \n");
                System.out.println("4 : N-Triple\n");
                choix = scanner.nextInt();
            }catch(Exception e) {
                System.err.println("**Veuillez entrer un des chiffres inscrits dans le menu**");
                scanner.nextLine();
                choix = null;
            }
            if(choix != null && !(choix == 1  || choix == 2 || choix == 3 || choix == 4)){
                scanner.nextLine();
                choix = null;
            }
        }while(choix == null);

        scanner.close();


        String choixS= null;
        switch(choix.intValue()) {
            case 2 : choixS = "TURTLE";break;
            case 3 : choixS = "RDF/JSON";break;
            case 4 : choixS = "N-TRIPLE";
        }

        return choixS;
    }


    /**
     * Création du graphe de Jupiter
     */
    public static void grapheRDF() {
        Model model = ModelFactory.createDefaultModel();

        //déclaration des espaces de noms
        String mus = "http://data.doremus.org/ontology#";
        String schema = "https://schema.org/";
        String dbp = "https://dbpedia.org/property/";
        String foaf = "http://xmlns.com/foaf/0.1/";

        //déclaration des resources
        Resource racine = model.createResource("https://dbpedia.org/page/Symphony_No._41_(Mozart)");
        Resource rKey = model.createResource("https://dbpedia.org/page/C_major");
        Resource rMozart = model.createResource("https://dbpedia.org/page/Wolfgang_Amadeus_Mozart");
        Resource rGenre = model.createResource("https://dbpedia.org/page/Symphony");
        Resource rAllegroVivace = model.createResource("https://dbpedia.org/page/Symphony_No._41_(Mozart)__Sound__1");
        Resource rMenuetto = model.createResource("https://dbpedia.org/page/Symphony_No._41_(Mozart)__Sound__3");
        Resource rAndanteCantabile = model.createResource("https://dbpedia.org/page/Symphony_No._41_(Mozart)__Sound__2");
        Resource rMoltoAllegro = model.createResource("https://dbpedia.org/page/Symphony_No._41_(Mozart)__Sound__4");
        Resource rEnregistrement = model.createResource("https://www.cleverte.fr/Mozart-/Symphonien-No-41-Jupiter/32311");
        Resource rConducteur = model.createResource("https://dbpedia.org/page/Claudio_Abbado");
        Resource rOrchestre = model.createResource("https://dbpedia.org/page/London_Philharmonic_Orchestra");
        Resource rLondres = model.createResource("https://dbpedia.org/page/London");

        //déclaration des propriétés
        Property key = model.createProperty(dbp+"key");
        Property composer = model.createProperty(dbp+"composer");
        Property subtitle = model.createProperty(dbp+"subtitle");
        Property name = model.createProperty(dbp+"name");
        Property genre = model.createProperty(mus+"U12_has_genre");
        Property tempo = model.createProperty(mus+"U14_has_tempo");
        Property recording = model.createProperty(mus+"U51i_has_partial_or_full_recording");
        Property conductor = model.createProperty(dbp+"conductor");
        Property orchestra = model.createProperty(dbp+"orchestra");
        Property city = model.createProperty(dbp+"city");
        Property title = model.createProperty(dbp+"title");
        Property firstname = model.createProperty(foaf+"firstName");
        Property lastname = model.createProperty(foaf+"lastName");
        Property year = model.createProperty(dbp+"year");

        //ajout des liens entre les resources
        model.add(racine, composer, rMozart).add(racine, genre, rGenre).add(racine, tempo, rAllegroVivace);
        model.add(racine, tempo, rMenuetto).add(racine, tempo, rAndanteCantabile).add(racine,tempo,rMoltoAllegro);
        model.add(racine, recording, rEnregistrement).add(racine, key, rKey);
        racine.addProperty(subtitle, "Jupiter").addProperty(name, "Symphonie no 41");

        rMozart.addProperty(firstname, "Wolfgang").addProperty(lastname, "Mozart");

        rAllegroVivace.addProperty(title, "1st movement").addProperty(title, "Allegro Vivace");
        rAndanteCantabile.addProperty(title, "2nd movement").addProperty(title, "Andante Cantabile");
        rMenuetto.addProperty(title, "3rd movement").addProperty(title, "Menuetto");
        rMoltoAllegro.addProperty(title, "4th movement").addProperty(title, "Molto Allegro");

        rEnregistrement.addProperty(year, "1980").addProperty(conductor, rConducteur).addProperty(orchestra, rOrchestre);

        rConducteur.addProperty(firstname, "Claudio").addProperty(lastname, "Abbado");

        rOrchestre.addProperty(city, rLondres);

        //remplacement des espaces de noms tampons par les vrais espaces de noms
        model.setNsPrefix("dbp", dbp);
        model.setNsPrefix("mus", mus);
        model.setNsPrefix("schema", schema);
        model.setNsPrefix("foaf", foaf);

        //choix de l'extension par l'utilisateur
        String extension = choixExtension();
        if(extension == null)
            model.write(System.out);
        else
            model.write(System.out, extension);

    }
}